Pista = 6
Szamolas = Pista + 4
print(Szamolas)
