pontszam = int(input())
if(pontszam < 60):
    print("elegtelen")
elif(pontszam < 70):
    print("elegseges")
elif(pontszam < 80):
    print("kozepes")
elif(pontszam < 90):
    print("jo")
else:
    print("jeles")

